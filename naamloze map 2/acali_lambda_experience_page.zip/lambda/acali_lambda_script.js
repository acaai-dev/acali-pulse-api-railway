
const slider = document.getElementById("comfortSlider");
const feedback = document.getElementById("feedback");

const defaultState = {
    co2: 800,
    presence: true,
    light_level: 300
};

let simulationState = { ...defaultState };
let intervalId = null;

function setSlider(value) {
    slider.value = value;
}

async function updateComfort() {
    const sliderValue = parseInt(slider.value);
    const temperature = 19 + (sliderValue / 100) * 8;

    const response = await fetch("https://c36eed6f-890f-4119-9dae-65c8789140fb-00-1nizqk4e1p5uc.picard.replit.dev/comfort", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            temperature,
            co2: simulationState.co2,
            presence: simulationState.presence,
            light_level: simulationState.light_level
        })
    });

    const data = await response.json();
    const statusColor = data.status === "comfortable" ? "#e6f4ea" : "#fdecea";
    const textColor = data.status === "comfortable" ? "#1a7f37" : "#b3261e";
    const emoji = data.status === "comfortable" ? "✅" : "⚠️";

    feedback.innerHTML = `
        <div style="background-color: ${statusColor}; color: ${textColor}; padding: 1rem; border-radius: 12px;">
            <strong>Status:</strong> ${emoji} ${data.status}<br>
            <strong>Aanbeveling:</strong> ${data.recommendation}
        </div>
    `;
}

function startDemoLoop() {
    let step = 0;
    intervalId = setInterval(() => {
        switch (step) {
            case 0:
                setSlider(30);
                simulationState = { ...defaultState };
                break;
            case 1:
                setSlider(80);
                break;
            case 2:
                simulationState.co2 = 1400;
                break;
            case 3:
                simulationState.light_level = 60;
                break;
            case 4:
                simulationState.presence = false;
                break;
            case 5:
                simulationState = { ...defaultState };
                setSlider(50);
                break;
        }
        updateComfort();
        step = (step + 1) % 6;
    }, 3000);
}

window.onload = () => {
    updateComfort();
    startDemoLoop();
};
