import React from 'react';
import './App.css';

// Kleuren gebaseerd op jouw stijlfiche
const colors = {
  pulse: '#A8EDB4',
  kosmos: '#CDBDFF',
  orbit: '#FFD385',
  flow: '#A8EFFF',
  insights: '#558DFF',
  token: '#CC9966',
};

// Voorbeeld: ModuleCard component
export const ModuleCard = ({ title, description, type }) => {
  const color = colors[type] || '#E2E8F0';
  return (
    <div className="rounded-2xl shadow-lg p-6 bg-white border-l-8 mb-4" style={{ borderColor: color }}>
      <h2 className="text-xl font-semibold mb-2" style={{ color }}>{title}</h2>
      <p className="text-gray-700 text-base">{description}</p>
    </div>
  );
};

// Voorbeeld: DashboardLayout
export const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gray-100 p-10">
      <h1 className="text-3xl font-bold mb-6">ACAΛI Modules</h1>
      <ModuleCard title="Pulse" type="pulse" description="Realtime energiebesparing & gedragsanalyse" />
      <ModuleCard title="Kosmos" type="kosmos" description="Biometrie, comfortprofielen en mensgerichte AI" />
      <ModuleCard title="Orbit" type="orbit" description="Bewegingspatronen & heatmaps voor optimalisatie" />
      <ModuleCard title="Flow" type="flow" description="Luchtkwaliteit, ventilatie & ademend ritme" />
      <ModuleCard title="Insights" type="insights" description="Dashboards, rapportering & slimme aanbevelingen" />
      <ModuleCard title="Tokenization" type="token" description="Gedrag, energie & CO₂ omgezet in waarde" />
    </div>
  );
};
