
const slider = document.getElementById("comfortSlider");
const feedback = document.getElementById("feedback");

const defaultState = {
    co2: 800,
    presence: true,
    light_level: 300
};

let simulationState = { ...defaultState };

async function updateComfort() {
    const sliderValue = parseInt(slider.value);
    const temperature = 19 + (sliderValue / 100) * 8;

    const response = await fetch("https://c36eed6f-890f-4119-9dae-65c8789140fb-00-1nizqk4e1p5uc.picard.replit.dev/comfort", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            temperature,
            co2: simulationState.co2,
            presence: simulationState.presence,
            light_level: simulationState.light_level
        })
    });

    const data = await response.json();
    const statusColor = data.status === "comfortable" ? "#e6f4ea" : "#fdecea";
    const textColor = data.status === "comfortable" ? "#1a7f37" : "#b3261e";
    const emoji = data.status === "comfortable" ? "✅" : "⚠️";

    feedback.innerHTML = `
        <div style="background-color: ${statusColor}; color: ${textColor}; padding: 1rem; border-radius: 12px;">
            <strong>Status:</strong> ${emoji} ${data.status}<br>
            <strong>Aanbeveling:</strong> ${data.recommendation}
        </div>
    `;
}

slider.addEventListener("input", updateComfort);

// Simulatieknoppen
document.getElementById("btnCo2").addEventListener("click", () => {
    simulationState.co2 = 1400;
    updateComfort();
});

document.getElementById("btnLight").addEventListener("click", () => {
    simulationState.light_level = 80;
    updateComfort();
});

document.getElementById("btnPresence").addEventListener("click", () => {
    simulationState.presence = false;
    updateComfort();
});

document.getElementById("btnReset").addEventListener("click", () => {
    simulationState = { ...defaultState };
    updateComfort();
});
