# ACAΛI Lambda UI

De frontend-interface van ACAΛI, bestaande uit een eenvoudige slider en live communicatie met de Pulse API.

## Bestanden

- `index.html` – hoofdpagina met UI
- `acali_lambda_script.js` – logica voor API-koppeling
